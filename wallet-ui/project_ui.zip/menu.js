const GENERATE_OTP_URL="http://localhost:5050/electronic-address/generate-otp"
const VERIFY_OTP_URL="http://localhost:5050/electronic-address/verify-otp"
const IS_EMAIL_VERIFIED="http://localhost:5050/electronic-address/isEmailVerified"
const IS_PHONE_VERIFIED="http://localhost:5050/electronic-address/isPhoneVerified"
const SEND_MONEY_TO_USER="http://localhost:5050/send-transaction"
const REQUEST_MONEY_TO_USER="http://localhost:5050/request-transaction"
const FETCH_WALLET_AMOUNT="http://localhost:5050/user-account/get-current-amount"
const DEDUCT_MONEY_FROM_BANK_TO_VERIFY="http://localhost:5050/user-account/deduct-money-from-bank-to-verify"
window.onload = function() {
  loadVariableValueInMainPage()
  isEmailVerified()
  isPhoneVerified()
  document.getElementById("main").style.display="block";
}

function isEmailVerified(){
  const data=JSON.parse(document.cookie).ssn;
  postData(IS_EMAIL_VERIFIED, data)
  .then(data => data.text())
  .then(data => {
      if (data==="Verified") {
        document.getElementById("verifyEmail").style.backgroundColor="#05C342";
        document.getElementById("verifyEmail").style.color="white";
        document.getElementById("verifyEmail").innerHTML='<b><i class="fas fa-check-circle"></i> Verified</b>';
        document.getElementById("verifyEmail").disabled = true;

      }
  })
}
function isPhoneVerified(){
  const data=JSON.parse(document.cookie).ssn;
  postData(IS_PHONE_VERIFIED, data)
  .then(data => data.text())
  .then(data => {
      if (data==="Verified") {
        document.getElementById("verifyPhone").style.backgroundColor="#05C342";
        document.getElementById("verifyPhone").style.color="white";
        document.getElementById("verifyPhone").innerHTML='<b><i class="fas fa-check-circle"></i> Verified</b>';
        document.getElementById("verifyPhone").disabled = true;
      }
  })
}
function sendMoneyToUser(){
  const data={
    "identifier":document.getElementById("email").value,
    "ssn":JSON.parse(document.cookie).ssn,
    "amount":document.getElementById("amount").value,
    "memo":document.getElementById("memo").value
}
  postData(SEND_MONEY_TO_USER, data)
  .then(data => {
    if (data.ok) {
        alert('successfully sent money')
    } else {
        alert('oops something went wrong...', data.json())
    }
})
}
function requestMoneyFromUser(){
  const data={
    "identifier":document.getElementById("requestEmail").value,
    "ssn":JSON.parse(document.cookie).ssn,
    "amount":document.getElementById("requestAmount").value,
    "memo":document.getElementById("requestMemo").value
}
  postData(REQUEST_MONEY_TO_USER, data)
  .then(data => {
    if (data.ok) {
        alert('successfully requested money')
    } else {
        alert('oops something went wrong...', data.json())
    }
})
}
function loadVariableValueInMainPage(){
  let dataArray=JSON.parse(document.cookie)
  let firstName=dataArray.firstname;
  document.getElementById("firstNameSpan").innerHTML=firstName;
  let ssn=dataArray.ssn;
  document.getElementById("ssnSpan").innerHTML=ssn;
  data=JSON.parse(document.cookie).ssn;
  postData(FETCH_WALLET_AMOUNT,data)
  .then(data => data.json())
  .then(data => {
      if (data!=null) {
          document.getElementById("walletBalanceSpan").innerHTML=data;
      } else {
          alert("Something went wrong");
      }
  })
}

function generate(ele,id){
  loadOTPPage(id);
  let data="";
  if(id === "phoneSubmitOTP"){
    data=JSON.parse(document.cookie).phoneno;
  }
  else{
    data=JSON.parse(document.cookie).email;
  }
  
  postData(GENERATE_OTP_URL, data)
  .then(data => data.json())
  .then(data => {
      if (data!=null) {
          alert("Your otp is "+data)
      } else {
          alert("Something went wrong");
      }
  })
}
function generateMoneyToVerifyFromBank(ele,id){
  loadOTPPage(id);
  const data=JSON.parse(document.cookie).ssn;
  postData(DEDUCT_MONEY_FROM_BANK_TO_VERIFY, data)
  .then(data => data.json())
  .then(data => {
      if (data!=null) {
          alert("$"+data+"is deducted from your bank. Please enter the same amount to verify bank.")
      } else {
          alert("Something went wrong");
      }
  })
}
function verifyBank(ele,id){
  const data={
    "identifier":document.getElementById("emailOTP").value,
    "otp": parseInt(document.getElementById("oneTimePasswordEmail").value),
    "ssn":JSON.parse(document.cookie).ssn
}
postData(VERIFY_OTP_URL, data)
.then(data => {
  if (data.ok) {
      alert('Email has been verified');
      document.getElementById("verifyEmail").style.backgroundColor="#05C342";
      document.getElementById("verifyEmail").style.color="white";
      document.getElementById("verifyEmail").innerHTML='<b><i class="fas fa-check-circle"></i> Verified</b>';
  } else {
      alert('oops something went wrong...', data.json())
  }
})
}
function verifyEmail(ele,id){
  document.getElementById(id).style.display="none";
  const data={
    "identifier":document.getElementById("emailOTP").value,
    "otp": parseInt(document.getElementById("oneTimePasswordEmail").value),
    "ssn":JSON.parse(document.cookie).ssn
}
postData(VERIFY_OTP_URL, data)
.then(data => {
  if (data.ok) {
      alert('Email has been verified');
      document.getElementById("verifyEmail").style.backgroundColor="#05C342";
      document.getElementById("verifyEmail").style.color="white";
      document.getElementById("verifyEmail").innerHTML='<b><i class="fas fa-check-circle"></i> Verified</b>';
  } else {
      alert('oops something went wrong...', data.json())
  }
})

}

function verifyPhone(ele,id){
  document.getElementById(id).style.display="none";
  const data={
    "identifier":document.getElementById("phoneOTP").value,
    "otp": parseInt(document.getElementById("oneTimePasswordPhone").value),
    "ssn":JSON.parse(document.cookie).ssn
}
postData(VERIFY_OTP_URL, data)
.then(data => {
  if (data.ok) {
      alert('Phone has been verified');
      document.getElementById("verifyPhone").style.backgroundColor="#05C342";
      document.getElementById("verifyPhone").style.color="white";
      document.getElementById("verifyPhone").innerHTML='<b><i class="fas fa-check-circle"></i> Verified</b>';
  } else {
      alert('oops something went wrong...', data.json())
  }
})
}


async function postData(url, data) {
const response = await fetch(url, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify(data)

})
return response
}

function loadOTPPage(id){
  document.getElementById(id).style.display="block";
}
function changeColor(ele,id){
    let i;
    let j;
    let btnId=document.getElementsByClassName("tabContainer");
    for(j=0;j<btnId.length;j++){
        btnId[j].style.display="none";
    }
    let button_num=document.getElementsByClassName("tablink");
    for(i=0;i<button_num.length;i++){
      button_num[i].style.color="white";
      button_num[i].style.backgroundColor="#54ABDC";
    }
    ele.style="Color:white";
    ele.style.backgroundColor="#02428E";
    document.getElementById(id).style.display="block";
    }

  function sendPageDisplay(ele){document.getElementById("sendMoney").style.display="block";}

  function requestPageDisplay(ele){document.getElementById("requestMoney").style.display="block";}

    // Close Send Page
  function closeSendPage(){document.getElementById("sendMoney").style.display="none";}
    // Close Request Page
  function closeRequestPage(){document.getElementById("requestMoney").style.display="none";}
  // Close Page
  function closePage(ele,id){document.getElementById(id).style.display="none";}

